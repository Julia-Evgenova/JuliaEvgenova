const renderMain = () => `<canvas id='sdsd'></canvas>`;


